
def lambda_handler(event, context):
    print("It's aliiive!!!")
